---
name: Parent BOM pom.xml rules
alwaysApply: true
---

# Acme Parent BOM Rules

This repository is `acme-parent-bom` — the corporate parent POM. It contains
zero Java source code. Its only job is to centralize:

  - Dependency versions (`<dependencyManagement>`)
  - Plugin versions (`<build><pluginManagement>`)
  - Build conventions (Java version, encoding, compiler flags)
  - Distribution management (where releases get published)

Consumers of this BOM are the common library and all application repos.

---

## Immutable contract

When suggesting changes, respect these rules:

  1. NEVER add a Java source file. NEVER suggest creating `src/main/java`.
     This is a `<packaging>pom</packaging>` artifact only.

  2. NEVER add `<dependencies>` to this POM. Only `<dependencyManagement>`.
     A `<dependency>` here would force every consuming app to pull that
     library whether they need it or not.

  3. NEVER add app-specific dependencies. If only one app uses a library,
     it does NOT belong here. The BOM is for shared baselines.

  4. EVERY version in `<dependencyManagement>` MUST come from a `${...}`
     property in `<properties>`. Inline versions are forbidden — they make
     security patching require a hand-edit per dependency.

  5. Property names follow Spring Boot's convention:
     `<technology>.version`, lowercase, dot-separated. Examples:
     `jackson.version`, `postgresql.version`, `lombok.version`.

  6. Major version bumps (of any managed library) require a CHANGELOG.md
     entry and at least a SemVer-minor bump of the BOM's own version.

  7. NEVER pin a version that conflicts with the imported Spring Boot BOM
     without an explicit comment justifying the override (CVE number,
     bug ID, or specific feature requirement).

  8. The BOM is published to the internal Nexus / Artifactory only.
     NEVER change `<distributionManagement>` URLs to public Maven Central,
     JitPack, or any external service.

---

## Standard layout

The pom.xml has these top-level sections, in this order:

  1. `<modelVersion>`, `<groupId>`, `<artifactId>`, `<version>`, `<packaging>pom</packaging>`
  2. `<name>`, `<description>`
  3. `<parent>` — inherits from `spring-boot-starter-parent`
  4. `<properties>` — every managed version
  5. `<dependencyManagement>` — every managed dependency
  6. `<build>` with `<pluginManagement>` only
  7. `<distributionManagement>`
  8. `<scm>`

---

## Adding a new managed dependency (two-step pattern)

ALWAYS in this order:

Step 1 — add a property in `<properties>`:

```xml
<postgresql.version>42.7.4</postgresql.version>
```

Step 2 — add the entry to `<dependencyManagement>`:

```xml
<dependency>
  <groupId>org.postgresql</groupId>
  <artifactId>postgresql</artifactId>
  <version>${postgresql.version}</version>
</dependency>
```

NEVER inline the version. NEVER add to `<dependencies>`.

---

## Importing another BOM (multi-artifact projects)

For SDKs that publish their own BOM (AWS SDK v2, Spring Cloud,
Testcontainers, Jackson, etc.), use `import` scope instead of pinning each
artifact individually:

```xml
<dependency>
  <groupId>software.amazon.awssdk</groupId>
  <artifactId>bom</artifactId>
  <version>${aws.sdk.version}</version>
  <type>pom</type>
  <scope>import</scope>
</dependency>
```

Imports MUST appear AFTER the `spring-boot-dependencies` import. Maven
resolves imports in declared order; Spring Boot's BOM is the foundation.

---

## Properties section discipline

Order properties as follows:

  1. Encoding and Java version (always at top)
  2. Maven plugin versions (`maven-*-plugin.version`) — those NOT pinned
     by Spring Boot parent
  3. Spring versions (only explicit overrides — most are managed by parent)
  4. Test framework versions (only overrides)
  5. Third-party library versions, alphabetized
  6. Internal/Acme library versions (last)

Every property defined MUST be referenced somewhere in
`<dependencyManagement>` or `<pluginManagement>`. Flag any unused property
when reviewing — they accumulate and confuse maintainers.

---

## Plugin management

Build plugins go in `<build><pluginManagement><plugins>`, NEVER directly in
`<build><plugins>` of the BOM. The BOM declares versions and default
config; consumers activate plugins as needed.

The standard plugin set this BOM manages:

  - `maven-compiler-plugin` (Java release version)
  - `maven-surefire-plugin` (test running, JVM args for Mockito + Java 21)
  - `maven-failsafe-plugin` (integration tests)
  - `maven-enforcer-plugin` (banned dependencies, version checks)
  - `spring-boot-maven-plugin` (build executable jars — declared, not activated)
  - `jacoco-maven-plugin` (coverage)
  - `dependency-check-maven` (OWASP CVE scanning)

The only plugin actively activated in `<build><plugins>` is
`maven-enforcer-plugin` — so the BOM validates its own constraints when built.

---

## Removing a managed dependency

Removing is a BREAKING CHANGE for consumers. When asked to remove:

  1. Search for callers first. If you cannot search the consuming repos,
     FLAG to the user before removing.
  2. Bump the BOM's own version with at least a SemVer-minor increment.
  3. Add a CHANGELOG.md entry under "Removed" naming the dependency and
     telling consumers what to do.

---

## Bumping versions

For patch and minor library bumps (e.g. `42.7.4` → `42.7.5` or
`42.7` → `42.8`):

  - Update only the property value
  - Patch-bump the BOM's own version

For major library bumps (e.g. `42.x` → `43.x`):

  - Update the property value
  - Add a CHANGELOG.md entry
  - Minor-bump the BOM's own version (consumers test before adopting)

When asked to bump Spring Boot, change ONLY `spring-boot.version` (the
parent's version). Do NOT change individual library versions Spring Boot
manages (Jackson, Hibernate, etc.) unless an override property already
exists in `<properties>` — those will adjust automatically when Spring
Boot's transitive BOM is re-resolved.

---

## CVE response

When asked to patch a CVE:

  1. Identify the affected library and minimum safe version from the CVE
     advisory.
  2. If the library is managed by Spring Boot's BOM, check whether bumping
     `spring-boot.version` to the latest patch picks up the fix
     automatically. PREFER that over a direct override.
  3. If a direct override is necessary, set the corresponding
     `${...}.version` property and add an inline comment:

     ```xml
     <!-- CVE-2024-XXXXX: pinned above Spring Boot's managed version -->
     <jackson.version>2.17.2</jackson.version>
     ```

  4. Patch-bump the BOM and release.
  5. Notify consuming repo owners that they need to bump their parent
     reference.

NEVER suppress a CVE by lowering the OWASP threshold or adding a
suppression file entry without an explicit comment explaining why the CVE
is not exploitable in our usage.

---

## Anti-patterns to refuse

Refuse the following with a brief explanation, do NOT silently apply:

  - Adding any Java source file or `src/` directory.
  - Adding a `<dependencies>` block (transitive). Only
    `<dependencyManagement>` is allowed.
  - Inline versions in `<dependencyManagement>` entries (must use
    `${...}` properties).
  - Pinning Spring Framework, Spring Security, or Spring Data versions
    directly. They are managed by `spring-boot-dependencies`.
  - Pinning Jackson, Hibernate, JUnit, Mockito, AssertJ, or Logback
    individually — Spring Boot manages all of these. Override only with
    a CVE comment.
  - Adding `org.codehaus.jackson:*` (Jackson 1) — that is the legacy
    stack, not the target.
  - Adding `javax.servlet`, `javax.persistence`, `javax.validation`,
    `javax.annotation:javax.annotation-api` (legacy namespaces).
  - Adding `junit:junit` (JUnit 4) — target is JUnit Jupiter 5.x.
  - Changing `<distributionManagement>` URLs to public services.
  - Adding plugins to `<build><plugins>` (use `<pluginManagement>`).

---

## Investigation commands

When diagnosing dependency conflicts or version questions, suggest these:

```bash
# Show effective dependency tree with resolved versions
mvn dependency:tree -Dverbose

# Show why a specific version is being picked
mvn dependency:tree -Dincludes=com.fasterxml.jackson.core:jackson-databind

# Show the effective POM after parent inheritance and BOM imports
mvn help:effective-pom
```
