# Continue.dev Rules — Acme Modernization Project

Complete rule set for the Java 8 → Java 21, Spring 4 → Spring 6, Jackson 1
→ Jackson 2, javax → jakarta migration. **Struts → Spring MVC migration is
deferred to Phase 2** and is deliberately excluded here.

## What's in here

```
continue-rules/
├── bom-repo/
│   └── parent-bom-pom-rules.md       # 1 file — for acme-parent-bom only
├── common-library/
│   ├── 00-phase1-modernization.md    # the same modernization rule
│   └── 10-library-conventions.md     # library-specific rules
├── app-repo/
│   ├── 00-phase1-modernization.md    # the same modernization rule
│   └── 10-test-conventions.md        # JUnit 5 / Mockito 5 / AssertJ
└── README.md                          # this file
```

## Where each rule pack goes

| Repo                  | Rules to install                                                                    |
|-----------------------|-------------------------------------------------------------------------------------|
| `acme-parent-bom`     | `bom-repo/parent-bom-pom-rules.md` only                                             |
| `acme-common`         | `common-library/00-phase1-modernization.md` + `common-library/10-library-conventions.md` |
| Each `acme-app-*`     | `app-repo/00-phase1-modernization.md` + `app-repo/10-test-conventions.md`           |

The same `00-phase1-modernization.md` file is used in both common library
and app repos because the migration rules are identical for code repos.
The difference between common library and app is the *additional* rule —
library conventions vs. test conventions.

## Installation

For each repo, the same three commands. From the repo root:

```bash
mkdir -p .continue/rules
cp <relevant-rule-files>/*.md .continue/rules/
git add .continue/
git commit -m "chore: add Continue.dev modernization rules"
```

Concrete example for an app repo:

```bash
cd acme-app-orders
mkdir -p .continue/rules
cp /path/to/continue-rules/app-repo/*.md .continue/rules/
git add .continue/
git commit -m "chore: add Continue.dev modernization rules"
```

## How the rules activate

| File                              | Activation                                                |
|-----------------------------------|-----------------------------------------------------------|
| `parent-bom-pom-rules.md`         | always (every chat in BOM repo)                           |
| `00-phase1-modernization.md`      | always (every chat in common/app repo)                    |
| `10-library-conventions.md`       | always (every chat in common library repo)                |
| `10-test-conventions.md`          | only when editing files under `src/test/java`             |

Test conventions use a `globs` pattern so they don't pollute production
code chats. Everything else is `alwaysApply: true` because the rules are
narrow and consistently relevant.

## Why this layout

**One always-on modernization rule per repo, not five split files.** A
single 200-line file is easier to maintain than five 40-line files when
the rules are interlocking. The cost is no `globs`-based targeting; the
benefit is one mental model and one place to update when reality
changes.

**Test conventions are split out** because they ARE genuinely separate
concerns and using `globs: "**/src/test/**/*.java"` keeps them out of
production-code chats. This is the one case where splitting earns its
keep.

**The BOM repo gets a different rule entirely.** It has no Java code, so
sharing a rule with the code repos would be confusing — most of the
modernization rule is irrelevant when you're editing `pom.xml`. The
BOM rule focuses tightly on `<dependencyManagement>` discipline.

**The common library gets an extra rule.** Library code has constraints
app code doesn't (no Spring Boot starters, optional autoconfiguration,
public API discipline). That goes in its own file rather than being
mixed into the modernization rule.

## What's NOT in here (and why)

- **No Struts → Spring MVC rules.** That's Phase 2. The modernization
  rule explicitly tells the agent to leave Struts alone except for
  javax→jakarta and Java idiom updates inside action method bodies.
- **No JSP rewrite rules.** Same reason — that's Phase 2.
- **No Spring Data JPA rules.** Spring JDBC is staying as-is.
- **No CI/CD or Jenkinsfile rules.** Those are platform-team templates,
  not agent rules.
- **No deployment rules.** Out of scope for code-level modernization.

When you're ready for Phase 2, replace `00-phase1-modernization.md` (or
add a `00-phase2-struts.md` alongside it) with the Struts conversion
patterns. The rest of the rule set stays the same.

## Pairing with prompts

These rules work alongside the `/modernize` slash command (the few-shot
prompt file we built earlier). Rules tell the agent _how_ to write
modern Java continuously; the prompt is for _explicitly invoking_ a
modernization transformation on highlighted code. They reinforce each
other.

## Maintenance

When Spring Boot ships a new version (e.g. 3.3 → 3.4):

1. Update the version in `00-phase1-modernization.md` target stack.
2. Update the BOM rule's target stack table.
3. Read Spring Boot release notes for new banned/deprecated APIs and add
   to the anti-patterns sections as needed.

When the team learns a new lesson worth codifying:

1. Add a rule. Don't add it as a comment in code or a Slack message.
2. If the lesson is universally applicable, add to `00-phase1-modernization.md`.
3. If repo-type-specific, add to the relevant `10-*.md` file.

The rules are deliberately living documents.
