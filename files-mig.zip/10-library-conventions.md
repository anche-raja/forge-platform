---
name: Common library conventions
alwaysApply: true
---

# Acme Common Library Rules

This repository is `acme-common` — a shared library consumed by every Acme
application. It is NOT an application. There is no `main()`, no
`application.yml`, no embedded server.

The consuming apps include this library as a Maven dependency. What you put
in here ships into every app, so the bar for what belongs is high:

  - Cross-cutting utilities (date/time, JSON, validation helpers)
  - Shared DTOs and value types
  - Shared exceptions
  - Common Spring configuration that every app needs (e.g. shared Jackson
    config, common security beans)
  - Shared test utilities (in a `acme-common-test` module if applicable)

What does NOT belong:

  - Anything used by only one app
  - Business logic specific to a domain (orders, payments, customers)
  - REST controllers (apps own their HTTP surface)
  - JPA entities tied to a specific app's schema
  - `@SpringBootApplication` — this library is not a Boot app

---

## Library code vs. app code — key differences

### 1. Dependencies are `<scope>compile</scope>`, NOT starters

Apps use `spring-boot-starter-*` artifacts. Libraries should NOT — starters
pull in autoconfiguration and transitive scaffolding (Tomcat, Logback,
Actuator) that consumers may not want.

Use the underlying Spring artifacts directly:

  - `spring-context`, `spring-web`, `spring-tx` — yes
  - `spring-boot-starter`, `spring-boot-starter-web` — NO (consumer's choice)

If the library genuinely needs something a starter provides, depend on the
specific artifact, not the starter. Example: depend on
`com.fasterxml.jackson.core:jackson-databind`, not
`spring-boot-starter-json`.

### 2. Make Spring Boot autoconfiguration optional

If the library provides Spring beans that should auto-register in
consuming apps, ship an `AutoConfiguration` class registered via:

```
src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
```

Each line of that file is a fully-qualified `@AutoConfiguration` class.
This is the Spring Boot 3.x way (replaces `spring.factories`).

Use `@ConditionalOnClass`, `@ConditionalOnMissingBean`, or
`@ConditionalOnProperty` to ensure the library degrades gracefully when a
consumer doesn't have the relevant classpath or config.

### 3. NEVER inject `Environment`, `@Value`, or read system properties at construction

Library beans must NOT assume Spring Boot is present, or that any specific
config keys exist. Instead:

  - Accept configuration via typed constructor parameters
  - Provide a `@ConfigurationProperties` record that callers can populate
  - Default to safe values when config is absent

Bad:

```java
@Component
public class FeatureFlagClient {
  @Value("${feature.flag.endpoint}")
  private String endpoint;
}
```

Good:

```java
@ConfigurationProperties(prefix = "acme.feature-flag")
public record FeatureFlagProperties(URI endpoint, Duration timeout) {}

public class FeatureFlagClient {
  private final FeatureFlagProperties props;
  public FeatureFlagClient(FeatureFlagProperties props) { this.props = props; }
}
```

### 4. Public API discipline

Every public class and method in this library is part of the contract.
Breaking changes ripple to every app.

  - NEVER change a public method signature without bumping the library's
    SemVer minor (additive) or major (breaking).
  - Mark internal classes `package-private` or move them under a
    `.internal` package (consumers are expected to avoid `.internal`).
  - Prefer interfaces for public APIs; concrete classes can change.
  - Use wider parameter types and narrower return types for flexibility:
    accept `Collection<T>`, return `List<T>`.
  - Annotate types intended for external use with `@Deprecated(forRemoval = true, since = "x.y.z")`
    BEFORE removing them — give consumers a release cycle to migrate.

### 5. NO Lombok in public API surfaces

Lombok-generated `@Data`, `@Value`, `@Builder` are fine for internal
classes. But for a public DTO or interface, use plain Java (or records) so
consumers without Lombok aren't blocked.

### 6. Tests should not require a running Spring context

Library unit tests should be plain JUnit + Mockito. Reserve
`@SpringBootTest` and `@SpringJUnitConfig` for integration tests in a
separate `*-IT.java` test class run by Failsafe.

A library that requires Spring to test itself is hard to consume.

---

## Versioning

This library follows SemVer:

  - **MAJOR** — removed or renamed a public API, changed Java baseline,
    removed an autoconfiguration that apps depended on.
  - **MINOR** — added a public API (additive), added a new
    autoconfiguration, bumped the parent BOM by minor.
  - **PATCH** — internal changes, bug fixes, parent BOM patch bumps.

Snapshot artifacts publish to `acme-internal-snapshots`. Release artifacts
publish to `acme-internal-releases`.

---

## When asked to add a feature

Before suggesting code, ask:

  1. Is this used by more than one app? If only one app needs it, it
     belongs in that app, not here. Push back to the user.
  2. Does it require classpath assumptions (Spring Boot, JPA, AWS SDK)?
     If yes, ship as optional autoconfiguration with `@ConditionalOnClass`.
  3. Is it stable enough to commit to as public API? If experimental,
     suggest a `.internal` package or a `@Beta`-style annotation.

---

## Anti-patterns to refuse

  - Adding `spring-boot-starter-*` dependencies (use the underlying
    artifact instead).
  - Adding `@SpringBootApplication`, `@EnableAutoConfiguration` directly
    on a library class.
  - Field `@Value` or `Environment` injection on a public class.
  - Inheriting from app-specific base classes (the library should depend
    on no app).
  - Adding business logic specific to one domain (orders, payments, etc.).
  - Using Lombok on classes intended as public API (records or plain Java
    instead).
  - Adding REST controllers (`@Controller`, `@RestController`) — apps own
    their HTTP surface.
