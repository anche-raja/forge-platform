---
name: Test conventions
globs: "**/src/test/**/*.java"
description: JUnit 5 / Mockito 5 / AssertJ patterns when touching test files
alwaysApply: false
---

# Test Conventions

Applies when editing files under `src/test/java`.

---

## Framework targets

  - JUnit Jupiter 5.10+ (`org.junit.jupiter.api.*`) — NOT JUnit 4
  - Mockito 5.x with byte-buddy-agent
  - AssertJ for assertions — NOT Hamcrest, NOT plain JUnit assertions
  - Testcontainers for integration tests requiring real DBs / queues

---

## JUnit 4 → JUnit 5 mappings

  - `@Before` → `@BeforeEach`
  - `@After` → `@AfterEach`
  - `@BeforeClass` → `@BeforeAll` (must be `static`)
  - `@AfterClass` → `@AfterAll` (must be `static`)
  - `@Ignore` → `@Disabled`
  - `@Test(expected = X.class)` → `assertThrows(X.class, () -> ...)`
  - `@Test(timeout = 1000)` → `@Timeout(1)` (seconds by default)
  - `@RunWith(SpringRunner.class)` → `@ExtendWith(SpringExtension.class)`
    or `@SpringJUnitConfig`
  - `@RunWith(MockitoJUnitRunner.class)` → `@ExtendWith(MockitoExtension.class)`
  - `@RunWith(Parameterized.class)` → `@ParameterizedTest` with
    `@MethodSource` / `@ValueSource` / `@CsvSource`

JUnit 5 imports are `org.junit.jupiter.api.*`. JUnit 4 imports are
`org.junit.*`. Never mix them in the same file.

---

## Mockito patterns

  - Use `@ExtendWith(MockitoExtension.class)` at the class level instead
    of `MockitoAnnotations.openMocks(this)` in `@BeforeEach`.
  - Annotate fields with `@Mock`, the system under test with `@InjectMocks`.
  - Prefer constructor injection over `@InjectMocks`:

    ```java
    private final OrderService service;
    private final OrderRepository repo = mock(OrderRepository.class);

    OrderServiceTest() { this.service = new OrderService(repo); }
    ```

  - For `void` methods: `doThrow(...).when(mock).method(...)`,
    `doNothing().when(mock).method(...)`.
  - `verify(mock, times(1)).method(...)` — explicit times even for the
    default 1, makes intent clear.
  - `ArgumentCaptor` for asserting on values passed to mocks.

NEVER use `PowerMock` — it doesn't work cleanly on Java 21. If the legacy
test relies on PowerMock to mock statics, refactor the production code to
inject a collaborator instead, or use Mockito's `mockStatic` (5.x+).

---

## AssertJ patterns

Replace JUnit / Hamcrest assertions with AssertJ:

  - `assertEquals(a, b)` → `assertThat(b).isEqualTo(a)`
  - `assertTrue(x)` → `assertThat(x).isTrue()`
  - `assertNull(x)` → `assertThat(x).isNull()`
  - `assertThat(list, hasSize(3))` → `assertThat(list).hasSize(3)`
  - `assertThat(map, hasEntry("k", "v"))` →
    `assertThat(map).containsEntry("k", "v")`
  - `assertThrows(X.class, ...)` is acceptable; AssertJ alternative is
    `assertThatThrownBy(() -> ...).isInstanceOf(X.class)` — prefer AssertJ
    when chaining further assertions on the exception.

Argument order matters: `assertThat(actual).isEqualTo(expected)`.

---

## Spring tests

  - `@SpringBootTest` for full-context integration tests. Slow; use
    sparingly.
  - `@WebMvcTest(MyController.class)` for controller-only slice tests.
  - `@DataJpaTest` for repository slice tests.
  - `@JdbcTest` for JdbcTemplate / JdbcClient tests.
  - `@MockBean` is deprecated in favour of `@MockitoBean` (Spring Boot 3.4+).
    Use `@MockitoBean` going forward.
  - `@SpringJUnitConfig` for plain Spring (no Boot) tests.

Default test class names:

  - Unit tests: `FooTest.java` — run by Surefire.
  - Integration tests: `FooIT.java` — run by Failsafe.

---

## Testcontainers

For tests that need a real DB / queue / cache:

  - Use `@Testcontainers` at class level + `@Container` on static fields.
  - Pin the container image to a specific version (`postgres:16.3` not
    `postgres:latest`) so CI is reproducible.
  - Reuse containers across tests via `withReuse(true)` + `~/.testcontainers.properties`
    setting `testcontainers.reuse.enable=true`.
  - For Spring Boot, prefer `@ServiceConnection` (Spring Boot 3.1+) over
    manually setting properties:

    ```java
    @Container
    @ServiceConnection
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16.3");
    ```

---

## Test data

  - Use record-based test fixtures (test data builders) over reflection /
    `ObjectMapper.readValue` from JSON files for unit tests.
  - For integration tests requiring a populated DB, prefer
    Testcontainers + `@Sql("/seed.sql")` over Hibernate's
    `import.sql` (which conflates production schema with test data).
  - Never hard-code timestamps in tests:
      - Wrong: `Instant.parse("2024-01-15T10:00:00Z")`
      - Right: inject a `Clock` and use `Clock.fixed(...)` in tests.

---

## Coverage and quality gates

  - JaCoCo runs in `verify` phase (configured in parent BOM).
  - Aim for ≥ 80% line coverage on production code, but coverage is a
    floor not a ceiling — chase meaningful tests over coverage numbers.
  - Mutation testing (PIT) is optional and run on demand, not in CI.

---

## Anti-patterns to refuse

  - Adding `junit:junit` (JUnit 4) dependencies.
  - Adding `org.hamcrest:hamcrest` for new assertions (use AssertJ).
  - Adding `org.powermock:*` (incompatible with Java 21).
  - `@MockBean` in new tests (use `@MockitoBean` instead).
  - `Thread.sleep(...)` in tests — use Awaitility or proper async APIs.
  - Tests that depend on test-execution order.
  - Tests that hit real network endpoints (use Testcontainers or
    WireMock).
  - Hard-coded `new Date()` / `Instant.now()` — inject a `Clock`.
