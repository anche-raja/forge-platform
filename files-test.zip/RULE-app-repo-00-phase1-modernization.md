---
name: Phase 1 Modernization (Java 21, Spring 6, Jackson 2)
alwaysApply: true
---

# Acme Phase 1 Modernization Rules

This codebase is being modernized in two phases. **You are in Phase 1.**

  - **Phase 1 (current):** Java 8 → Java 21, Spring 4.x → Spring 6.x /
    Spring Boot 3.3.x, Jackson 1.x → Jackson 2.x, javax → jakarta.
  - **Phase 2 (later, NOT now):** Struts → Spring MVC.

Struts code is OUT OF SCOPE for Phase 1. It must continue to work on the
upgraded stack but should NOT be rewritten yet. See "Struts handling"
below for the exact rules.

---

## Target stack

  - Java 21 (LTS)
  - Spring Framework 6.2.x / Spring Boot 3.3.x
  - Jakarta EE 10 (`jakarta.*` namespace)
  - Jackson 2.17+ (`com.fasterxml.jackson.*`)
  - JUnit 5, SLF4J 2.x, Hibernate 6.x, Mockito 5.x

Apply ALL applicable transformations in a single pass when touching a file.
Do not partially modernize.

---

## Mandatory transformations

### 1. javax → jakarta (mandatory, no exceptions)

Replace these Jakarta EE namespaces:

  - `javax.servlet.*`            → `jakarta.servlet.*`
  - `javax.persistence.*`        → `jakarta.persistence.*`
  - `javax.validation.*`         → `jakarta.validation.*`
  - `javax.annotation.PostConstruct` / `PreDestroy` → `jakarta.annotation.*`
  - `javax.inject.*`             → `jakarta.inject.*`
  - `javax.transaction.Transactional` → prefer
    `org.springframework.transaction.annotation.Transactional`
  - `javax.ws.rs.*`              → `jakarta.ws.rs.*`
  - `javax.jms.*`                → `jakarta.jms.*`
  - `javax.mail.*`               → `jakarta.mail.*`

LEAVE alone (these are JDK packages, NOT Jakarta EE):
`javax.crypto.*`, `javax.sql.*`, `javax.net.*`, `javax.security.auth.*`,
`javax.naming.*`, `javax.xml.*`.

### 2. Spring 4.x → Spring 6.x

  - Field `@Autowired` → constructor injection. Mark dependencies `final`.
    Use Lombok `@RequiredArgsConstructor` if Lombok is on the classpath;
    otherwise hand-write the constructor.
  - `@RequestMapping(method = RequestMethod.GET)` → `@GetMapping`
    (and `@PostMapping`, `@PutMapping`, `@DeleteMapping`, `@PatchMapping`).
  - `RestTemplate` → `RestClient` (Spring 6.1+) for synchronous calls;
    use `WebClient` ONLY when the surrounding code is already reactive.
  - `AsyncRestTemplate` → `WebClient` (no synchronous successor).
  - `WebMvcConfigurerAdapter` → implement `WebMvcConfigurer` directly.
  - `@EnableGlobalMethodSecurity` → `@EnableMethodSecurity`.
  - `WebSecurityConfigurerAdapter` → `SecurityFilterChain` `@Bean`.
  - XML `<bean>` definitions → `@Configuration` + `@Bean` methods in a
    Java config class. Note the XML file as deletable in the migration
    log.

For controllers ALREADY annotated `@Controller` / `@RestController`:
apply the upgrades above WITHOUT renaming the class, repackaging it, or
restructuring methods. Drop unused `HttpServletRequest` parameters only
if they are not referenced (even via attribute lookup).

### 3. Spring JDBC

JdbcTemplate / NamedParameterJdbcTemplate are NOT deprecated and continue
to work in Spring 6. Working code stays.

For files being touched anyway, the modernization patterns are:

  - `JdbcTemplate` → `JdbcClient` (Spring 6.1+) for fluent named-parameter API.
  - Anonymous inner-class `RowMapper<T>` → `DataClassRowMapper<T>` as a
    `private static final` constant when the target type is a record or
    has a single all-args constructor.
  - `BeanPropertyRowMapper.newInstance(Foo.class)` →
    `new DataClassRowMapper<>(Foo.class)` when `Foo` is a record.
  - `queryForObject` + `EmptyResultDataAccessException` →
    `JdbcClient.query(...).optional()`. Treat as a contract change and
    update all callers.
  - SQL strings spanning multiple `+` concatenations → text block (`"""`).
  - `DataSource` stays `javax.sql.DataSource` (JDK package).

Do NOT migrate Spring JDBC to Spring Data JPA. Different paradigm,
different transaction semantics. Out of scope.

### 4. Jackson 1.x → Jackson 2.x

  - `org.codehaus.jackson.*` → `com.fasterxml.jackson.*`
  - `org.codehaus.jackson.map.ObjectMapper` →
    `com.fasterxml.jackson.databind.ObjectMapper`
  - `@JsonSerialize(include = Inclusion.NON_NULL)` →
    `@JsonInclude(JsonInclude.Include.NON_NULL)`
  - `SerializationConfig.Feature.X` → `SerializationFeature.X`
  - `DeserializationConfig.Feature.X` → `DeserializationFeature.X`
  - For `java.time.*` types, ALWAYS register `JavaTimeModule` and disable
    `SerializationFeature.WRITE_DATES_AS_TIMESTAMPS`.
  - Maven coordinates: remove `org.codehaus.jackson:jackson-mapper-asl`
    and `jackson-core-asl`; add `com.fasterxml.jackson.core:jackson-databind`
    and `com.fasterxml.jackson.datatype:jackson-datatype-jsr310`.

### 5. Java 8 → Java 21 idioms

Apply when the change is local and obvious; never reorganize across files.

  - Verbose immutable DTO with all-args constructor, getters,
    equals/hashCode/toString → `record`. Skip if the class extends another,
    has setters, or is a JPA `@Entity` (records cannot be entities).
  - `if/else if` cascade over an enum → switch expression with arrow syntax.
  - Multi-line string concatenation or `StringBuilder` → text block (`"""`).
  - `new ArrayList<String>()`, `new HashMap<String, Integer>()` etc. on the
    right-hand side of a local variable → `var` (only when the type is
    obvious from the RHS).
  - Anonymous `Runnable` / `Callable` / single-method listener → lambda or
    method reference.
  - `Collections.unmodifiableList(Arrays.asList(...))` → `List.of(...)`.

### 6. Java 21 removed/changed APIs (fix on sight)

  - `new URL(String)` → `URI.create(string).toURL()`.
  - `Thread.stop()` / `suspend()` / `resume()` → throw
    `UnsupportedOperationException` and emit `// TODO(migration):` comment.
  - `finalize()` overrides → remove, replace with `try-with-resources` or
    `Cleaner`. Flag as TODO.
  - `SecurityManager` → flag as TODO; no replacement exists.
  - `java.util.Date` / `Calendar` in NEW code positions → `java.time.Instant` /
    `LocalDate` / `LocalDateTime` / `ZonedDateTime`. Do NOT change existing
    public APIs that return `Date` — flag instead.
  - Classes defining `getFirst()` / `getLast()` / `addFirst()` / `addLast()` /
    `reversed()` → flag as TODO; may collide with `SequencedCollection`.

### 7. Logging

Replace Log4j 1.x `Logger.getLogger(X.class)` with SLF4J
`LoggerFactory.getLogger(X.class)`. Use parameterized messages
(`log.info("user {} logged in", id)`), never string concatenation.

---

## Struts handling (CRITICAL — Phase 2 work, NOT Phase 1)

If the file you are touching contains Struts artifacts, follow these
rules precisely:

  - DO NOT rewrite `Action` / `ActionSupport` / `ActionForm` classes into
    Spring controllers. That is Phase 2.
  - DO NOT delete `struts-config.xml`, `struts.xml`, or `validation.xml`.
  - DO NOT remove `org.apache.struts.*` imports.
  - DO apply the javax → jakarta replacements ABOVE on Struts files —
    Struts 2.5.x+ supports Jakarta. If the project is on Struts 1.x or
    Struts 2.3.x, FLAG it and stop; the Struts version itself needs an
    upgrade before Phase 1 can complete on those files.
  - DO replace Jackson 1.x imports in Struts files (the `json-default`
    result type uses Jackson under the hood — but if the `<result type>`
    config references it, that's Struts plumbing, leave it).
  - DO replace Log4j 1.x with SLF4J in Struts action classes.
  - DO modernize Java 8 idioms inside Struts action `execute()` method
    bodies (records for DTOs, switch expressions, var, text blocks).

In other words: modernize the Java *inside* a Struts action; do not
modernize the Struts *around* the action. Struts files should compile
and run on Java 21 + Spring 6 at the end of Phase 1, just still using
Struts.

If a transformation feels like it would need to delete or rename a
Struts artifact, STOP and emit a `// TODO(phase-2):` comment instead.

---

## General modernization conventions

  - Constructor injection only. No field `@Autowired`. Dependencies `final`.
  - SLF4J for logging. Parameterized messages. No string concatenation.
  - Records for immutable DTOs unless they are JPA entities, have setters,
    or extend another class.
  - `@ConfigurationProperties` records over scattered `@Value` injection.
  - Text blocks for multi-line strings.
  - Constructor-based `@Bean` methods over XML.

---

## OpenRewrite first, agent second

This project uses OpenRewrite for the bulk mechanical migration work.
You (the agent) handle the semantic work that OpenRewrite is deliberately
conservative about.

**Defer to OpenRewrite — don't do these by hand:**

  - `javax.*` → `jakarta.*` import rewrites across many files
  - `@RequestMapping(method = RequestMethod.X)` → `@GetMapping` etc.
  - JUnit 4 → JUnit 5 syntax (`@Before` → `@BeforeEach`, runners →
    extensions, `@Test(expected=)` → `assertThrows`)
  - `org.codehaus.jackson.*` → `com.fasterxml.jackson.*` package renames
    and `@JsonSerialize(include=...)` → `@JsonInclude` annotation rewrites
  - Spring Boot starter coordinate updates and version property bumps
  - `WebSecurityConfigurerAdapter` → `SecurityFilterChain`
  - `WebMvcConfigurerAdapter` → `WebMvcConfigurer`
  - Removing unused imports

If the user asks you to do bulk work in any of these categories, FIRST
suggest running OpenRewrite:

```bash
mvn -U rewrite:dryRun                        # preview
less target/site/rewrite/rewrite.patch        # review
mvn rewrite:run                               # apply
mvn clean verify                              # gate
```

The active recipe is `com.acme.migration.LegacyJavaModernization` defined
in `rewrite.yml` at the repo root. After OpenRewrite runs and tests pass,
the agent picks up the remaining work.

**Do these by hand (semantic work OpenRewrite won't do):**

  - `RestTemplate` → `RestClient` — requires choosing between RestClient
    and WebClient based on whether surrounding code is reactive
  - `JdbcTemplate` → `JdbcClient` — contract changes around `Optional`
    and exception handling that callers must adapt to
  - DTO classes → `record` — requires checking inheritance, setters,
    JPA usage, and updating every caller's `getX()` to `x()`
  - `if/else if` cascade → switch expression with arrow syntax
  - `java.util.Date` → `java.time.Instant` in field types — public API
    contract change requiring caller updates
  - `BeanPropertyRowMapper` → `DataClassRowMapper` for record types
  - Inline `BindingResult.hasErrors()` checks — keep or remove based on
    whether a global `@ControllerAdvice` exists; OpenRewrite can't tell
  - Constructor injection refactors that involve reordering fields or
    consolidating multiple constructors

These all require reading the surrounding code, understanding intent, or
making contract decisions. OpenRewrite's recipes are deliberately
conservative on these so they don't silently break things.

---

## Process discipline

When migrating a file:

  1. Preserve business logic verbatim. Never silently change conditionals,
     error handling, transactions, or data access. If behaviour is
     ambiguous, emit a `// TODO(migration):` comment instead of guessing.
  2. After a successful migration, append a row to `MIGRATION_LOG.md`
     in the SAME git commit as the code change.
  3. Run tests before considering a file done. Do not commit a file that
     fails compile or tests.
  4. Flag (do not silently fix) anything outside Phase 1 scope:
       - Struts artifacts beyond what this rule allows
       - JSP tag rewrites
       - Spring Data JPA migrations from JDBC
       - Hibernate naming-strategy schema diffs
       - SecurityManager removal
       - Public API changes (Date → Instant in returned types)

---

## Anti-patterns to refuse

Refuse the following with a brief explanation, do NOT silently apply:

  - Adding `javax.servlet`, `javax.persistence`, `javax.validation`,
    `javax.annotation` imports for Jakarta EE packages.
  - Adding `org.codehaus.jackson:*` (Jackson 1) dependencies or imports.
  - Adding `junit:junit` (JUnit 4) dependencies — target is JUnit Jupiter.
  - Adding `WebMvcConfigurerAdapter`, `WebSecurityConfigurerAdapter`, or
    `@EnableGlobalMethodSecurity` — all removed or deprecated.
  - Field `@Autowired` injection in new code.
  - Pinning Spring Framework, Jackson, Hibernate, or JUnit versions
    individually when Spring Boot's BOM manages them.
  - Migrating Struts to Spring MVC (defer to Phase 2).
  - Migrating Spring JDBC to Spring Data JPA (out of scope entirely).
