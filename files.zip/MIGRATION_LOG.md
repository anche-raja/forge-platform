<!--
================================================================================
AGENT INSTRUCTIONS — read before editing this file

You (Continue.dev / Claude Code agent) maintain this log as Phase 2-4 progress.

Rules:
1. Append, never silently rewrite. Old entries are an audit trail.
2. After EVERY successful file migration, add a row to the relevant phase
   table with: file path, status, git short SHA, agent or human, notes.
3. If a migration fails (compile error, test failure, ambiguous business
   logic), add a row with status=BLOCKED and a one-line reason. Do not
   guess — surface to the human.
4. When you discover something the human needs to do (JSP rewrites, missing
   tests, deprecated APIs with no recipe), add it to "Manual TODOs" with
   enough context that the human can act without re-reading the file.
5. Update the "Last updated" timestamp and "Current phase" header at the top.
6. Never delete TODOs — only check them off. Deleted TODOs disappear from
   the audit trail.
7. Commit this file in the SAME commit as the code change it describes.
   That way `git log MIGRATION_LOG.md` is the migration history.

Format note: tables use markdown pipes. Keep columns aligned for grep-ability.
================================================================================
-->

# Migration Log: `<repo-name>`

**Last updated:** `<YYYY-MM-DD HH:MM TZ>`
**Current phase:** `<1 | 2 | 3 | 4 | done>`
**Migration branch:** `migration-java21`
**Baseline tag:** `pre-migration-<YYYY-MM-DD>`

---

## Status overview

| Phase                                | Status      | Started      | Completed    | Notes |
|--------------------------------------|-------------|--------------|--------------|-------|
| 1. OpenRewrite mechanical            | not-started |              |              |       |
| 2.  Struts removal                   | not-started |              |              |       |
| 2b. Spring MVC polish                | not-started |              |              |       |
| 2c. Spring JDBC polish (optional)    | not-started |              |              |       |
| 3.  JSP layer                        | not-started |              |              |       |
| 4.  Java 21 idiom polish (optional)  | not-started |              |              |       |

Status values: `not-started` | `in-progress` | `blocked` | `done`

---

## Pre-flight checklist

- [ ] CI green on baseline (Java 8 / Spring 4 / Jackson 1) — record build URL: ___
- [ ] Branch `migration-java21` created from main: ___ (commit SHA)
- [ ] Baseline tag created: `git tag pre-migration-<date>` and pushed
- [ ] Parent BOM published as `X.Y.Z-MIGRATION-SNAPSHOT` to internal repo (apps + common only)
- [ ] Common library on `Y.Z-MIGRATION-SNAPSHOT` (apps only)
- [ ] Backup of any persisted JSON payloads / serialised sessions taken (Jackson date format change risk)

---

## Phase 1 — OpenRewrite mechanical migration

**Recipe:** `com.acme.migration.LegacyJavaModernization`

### Run record

| Step             | Result | Commit  | Notes |
|------------------|--------|---------|-------|
| `rewrite:dryRun` |        |         |       |
| `rewrite:run`    |        |         |       |
| `mvn verify`     |        |         |       |

### Files modified count (from `target/rewrite/datatables/*.csv`)

| Sub-recipe                              | Files touched |
|-----------------------------------------|---------------|
| Jackson CodehausToFasterXML             |               |
| UpgradeSpringBoot_3_3                   |               |
| UpgradeToJava21                         |               |
| RemoveUnusedImports                     |               |

### Issues found during Phase 1

(append a row per issue — don't edit existing rows)

| Date | Issue | Resolution | Commit |
|------|-------|------------|--------|
|      |       |            |        |

---

## Phase 2 — Struts removal (agent-driven, file-by-file)

Each row below is one Struts artifact migrated to Spring MVC. The agent
appends a row after each successful migration and a `BLOCKED` row if the
business logic is ambiguous.

| File (legacy path) | Target file(s) | Status | By | Commit | Notes |
|--------------------|----------------|--------|-----|--------|-------|
|                    |                |        |     |        |       |

### Struts files remaining

(agent: keep this list current — remove a file once it's migrated)

```
<run on day 1: find . -name '*.java' -exec grep -l 'org.apache.struts' {} \;>
<paste output here>
```

```
<run on day 1: find . -name 'struts*.xml' -o -name 'validation.xml'>
<paste output here>
```

### Manual TODOs from Phase 2

(agent appends — human checks off)

- [ ] _example_: `login.jsp` — `<html:form>` and `<html:errors>` need conversion to Spring `<form:form>` / `<form:errors>` (or Thymeleaf — see Phase 3).
- [ ] _example_: `ApplicationResources.properties` — rename to `messages.properties` and verify `MessageSource` bean wiring.
- [ ] _example_: `OrderAction.execute()` had embedded transaction logic. Verify the new `OrderController` -> `OrderService` boundary preserves transaction scope (was: implicit per-request, now: `@Transactional` on service).

---

## Phase 2b — Existing Spring MVC controllers (Spring 4 -> 6 polish)

These controllers were ALREADY on Spring MVC and only needed Spring 4 -> 6
upgrade work. OpenRewrite handles `@RequestMapping(method=...)` decomposition
and javax -> jakarta automatically in Phase 1, but the agent should still
sweep through to catch the things OpenRewrite is conservative about:
constructor injection, `@RestController` consolidation, `BindingResult`
handler-advice review, unused `HttpServletRequest` parameter pruning.

| File | OpenRewrite handled? | Agent reviewed? | Commit | Notes |
|------|----------------------|-----------------|--------|-------|
|      |                      |                 |        |       |

### Existing Spring MVC inventory

```
<run on day 1: grep -rln '@Controller\|@RestController' src/main/java>
<paste output here, exclude any already in Phase 2 because they came from Struts>
```

---

## Phase 2c — Spring JDBC DAOs

These are the existing DAO classes using `JdbcTemplate` /
`NamedParameterJdbcTemplate`. After Phase 1, they compile and run on
Spring 6 unchanged. Phase 2c is OPTIONAL polish — converting to `JdbcClient`,
introducing records, tightening null-vs-Optional contracts. Don't rush it;
working JDBC code is fine to leave alone.

| File | JdbcClient migration? | Records? | Commit | Notes |
|------|----------------------|----------|--------|-------|
|      |                      |          |        |       |

### Spring JDBC inventory

```
<run on day 1: grep -rln 'JdbcTemplate\|NamedParameterJdbcTemplate\|JdbcDaoSupport' src/main/java>
<paste output here>
```

### Manual TODOs from Phase 2c

- [ ] _example_: `OrderDao.findById()` returns `null` on miss. New `JdbcClient.optional()` returns `Optional.empty()`. Audit callers before flipping.
- [ ] _example_: `created_at` column → `Instant` field. Verify timezone handling — production DB stores `TIMESTAMP WITH TIME ZONE` (use `OffsetDateTime`) or naive `TIMESTAMP` (use `LocalDateTime`).

---

## Phase 3 — JSP layer

Path chosen (pick one and document why):

- [ ] **Path A — Spring `<form:>` tags** (lower-effort, lower-reward).
  Reason: ___
- [ ] **Path B — Thymeleaf** (higher-effort, modernises the view layer).
  Reason: ___
- [ ] **Path C — defer** (ship Phases 1-2 and tackle JSPs later).
  Reason: ___

| JSP file | Migrated to | Status | Commit | Notes |
|----------|-------------|--------|--------|-------|
|          |             |        |        |       |

---

## Phase 4 — Java 21 idiom polish (optional)

Only run after Phases 1-3 are merged to main. This phase introduces zero
behavioural change — it's pure readability work. Skip for files where the
team has no time to re-review.

| File | Records? | Switch expr? | Text blocks? | var? | Commit | Notes |
|------|----------|--------------|--------------|------|--------|-------|
|      |          |              |              |      |        |       |

### Files explicitly skipped

(some classes shouldn't become records — JPA entities, hierarchy roots,
classes with setters, classes inspected via reflection. Document the why.)

| File | Reason for skip |
|------|-----------------|
|      |                 |

---

## Cross-cutting follow-ups (post-merge)

These are the actions to take AFTER the migration branch is merged to main
and deployed to production. Don't do them as part of the migration PR —
keep them as separate tickets.

- [ ] Delete `struts.xml`, `struts-config.xml`, `validation.xml` (verify nothing left references them)
- [ ] Remove Maven dependencies: `struts-core`, `struts2-*`, `struts-tiles`, `struts2-spring-plugin`
- [ ] Remove Maven dependencies: `org.codehaus.jackson:*` (should be gone after Phase 1, but verify)
- [ ] Remove the OpenRewrite `<plugin>` block from `pom.xml` (keep `rewrite.yml` as documentation)
- [ ] Update README / onboarding docs: Java version, Spring version, build prereqs
- [ ] Update CI Dockerfile / build images to JDK 21
- [ ] Update IDE configuration files (`.editorconfig`, `.idea/`, etc.) if they pin a Java version
- [ ] Update `application.yml` / `application.properties` for any Spring Boot 3.3 property renames (the properties-migrator output during Phase 1 will list these — paste here):
  - [ ] _example_: `server.max-http-header-size` -> `server.max-http-request-header-size`
- [ ] Remove the `-MIGRATION-SNAPSHOT` qualifiers from the BOM and common library version refs once everyone has stabilised on the modern stack
- [ ] Audit `application.yml` for `spring.jpa.open-in-view: true` (defaults true, often wrong)
- [ ] Verify production Jackson behaviour — if any persisted JSON used numeric timestamps, the `JavaTimeModule` registration in Phase 1 will have changed serialisation format

---

## Appendix A — Commands cheat sheet

```bash
# Phase 1
mvn -U rewrite:dryRun
less target/site/rewrite/rewrite.patch
mvn rewrite:run
mvn clean verify
git add -A && git commit -m "Phase 1: OpenRewrite mechanical migration"

# Phase 2 (per file, in Continue.dev agent mode)
# Open the file -> /modernize -> review diff -> accept -> verify -> commit
mvn test -Dtest=<TestForMigratedFile>

# Periodic full-repo verification
mvn clean verify
mvn dependency:tree | grep -E '(struts|codehaus)' # should be empty after Phase 1

# Find next batch of Struts files
find . -name '*.java' -exec grep -l 'org.apache.struts' {} \;
```

---

## Appendix B — Known issues / lessons learned in this repo

(agent + humans both append. This is the team-knowledge section. Future
migrations of sister repos read this first.)

| Date | Lesson | Applies to |
|------|--------|------------|
|      |        |            |
