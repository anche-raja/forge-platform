---
name: Multi-module aggregator root
alwaysApply: true
---

# Multi-module Aggregator Root Rules

This repository is a multi-module Maven project. There is a ROOT pom.xml
at the repository root and one CHILD pom.xml inside each module
subdirectory. Each module is its own buildable artifact (a JAR).

When working in this repo, you must distinguish between the two kinds of
pom.xml. They have different purposes and different rules.

---

## Anatomy

```
<repo-root>/
├── pom.xml                          ← ROOT (aggregator + parent)
├── rewrite.yml                      ← OpenRewrite recipe (root only)
├── MIGRATION_LOG.md                 ← migration log (root only)
├── .continue/                       ← agent rules (root only)
│
├── validation/                      ← child module
│   ├── pom.xml                      ← MODULE pom
│   └── src/main/java/...
│
├── common/                          ← child module
│   ├── pom.xml                      ← MODULE pom
│   └── src/main/java/...
│
├── ...other modules...
│
└── target/                          ← build output (root + per module)
```

---

## ROOT pom.xml — what belongs here

The root pom.xml is BOTH the aggregator (lists modules to build) AND the
parent (modules inherit from it). It contains:

  - `<packaging>pom</packaging>` — REQUIRED, this is not a code artifact.
  - `<modules>` — lists every child module directory name.
  - `<parent>` — points at `acme-parent-bom` (the corporate BOM).
  - `<dependencyManagement>` — versions for libraries used across modules.
    These are managed but NOT pulled in transitively.
  - `<build><pluginManagement>` — plugin versions, including
    `rewrite-maven-plugin` for the migration.
  - `<properties>` — versions for managed dependencies, in `${...}` form.
  - Optionally a small `<dependencies>` block — but only for libraries
    EVERY module needs (Lombok, JUnit, etc.). Avoid this when possible
    and prefer module-level declarations.

The root pom MUST NOT contain:

  - `src/main/java` directory
  - Module-specific dependencies (those go in module poms)
  - Business logic of any kind

## CHILD pom.xml (validation/, common/, etc.) — what belongs here

Each module's pom.xml is a regular jar artifact. It contains:

  - `<parent>` — points at the ROOT pom (relativePath of `../pom.xml`).
  - `<artifactId>` — the module's own name (e.g. `acme-validation`).
  - `<dependencies>` — what this module needs at runtime / compile.
    Versions usually omitted (inherited from root's
    `<dependencyManagement>`).
  - `<build><plugins>` if the module needs plugin activation that root
    doesn't already provide.

The module pom MUST NOT:

  - Override the parent declaration
  - Repeat version numbers that are already in root's
    `<dependencyManagement>` — let inheritance do its job
  - Add `<modules>` of its own (modules are not nestable)
  - Pin Spring Framework / Jackson / Hibernate versions (those come from
    the corporate BOM via the root pom)

---

## Where the migration tooling lives

| File / artifact          | Location              | Why                                         |
|--------------------------|-----------------------|---------------------------------------------|
| `rewrite.yml`            | repo root only        | OpenRewrite resolves it from the root and applies recipes to all modules |
| `rewrite-maven-plugin`   | root pom, `pluginManagement` | Defined once, inherited by all modules; activated at root |
| `.continue/rules/`       | repo root only        | Continue.dev finds it from any subdirectory |
| `.continue/prompts/`     | repo root only        | Same                                         |
| `MIGRATION_LOG.md`       | repo root only        | One log per repo, covers all modules        |

There is exactly ONE of each of these per repo. NEVER duplicate them
into module subdirectories.

---

## Running OpenRewrite in a multi-module repo

Always run from the repo root, never from a module directory:

```bash
cd <repo-root>
mvn -U rewrite:dryRun     # processes all modules
mvn rewrite:run           # applies to all modules
mvn clean verify          # builds all modules
```

When the recipe runs from root, it parses every module's source code as
one project, applies recipes consistently across modules, and produces
one combined patch. Running from a single module loses cross-module
context (e.g. a record migration in `common/` won't update callers in
`validation/`).

If you need to migrate ONE module first as a smoke test:

```bash
mvn -pl validation rewrite:dryRun -am
```

`-pl` selects the module, `-am` ("also-make") includes its dependencies
so the build still works. Use sparingly — most migrations should be
all-or-nothing per repo.

---

## Versioning across modules

All modules in this repo share ONE version, defined in the root pom:

```xml
<groupId>com.acme</groupId>
<artifactId>acme-common</artifactId>
<version>2.0.0-SNAPSHOT</version>
<packaging>pom</packaging>
```

Each child module inherits the version implicitly:

```xml
<parent>
    <groupId>com.acme</groupId>
    <artifactId>acme-common</artifactId>
    <version>2.0.0-SNAPSHOT</version>
    <relativePath>../pom.xml</relativePath>
</parent>
<artifactId>acme-validation</artifactId>
<!-- no <version> tag — inherited from parent -->
```

When bumping the version, change it ONLY in the root pom. Child poms
inherit. NEVER hand-edit a version into a child pom — that's a sign the
inheritance is broken and needs investigation.

For Maven release plumbing, use `versions:set`:

```bash
mvn versions:set -DnewVersion=2.0.1-SNAPSHOT -DprocessAllModules
```

The `-DprocessAllModules` flag is critical — without it, only the root
pom version changes and module poms drift out of sync.

---

## Modules can depend on each other (intra-repo deps)

If `validation` depends on `common`, declare it in `validation/pom.xml`:

```xml
<dependency>
    <groupId>com.acme</groupId>
    <artifactId>acme-common</artifactId>
    <!-- no <version> — comes from root's dependencyManagement -->
</dependency>
```

Maven's reactor builds modules in dependency order automatically. You
don't need to specify build order in the root's `<modules>` list.

When asked to add an intra-repo dependency, ALWAYS:

  1. Verify the dependency exists in root's `<dependencyManagement>`. If
     not, add it there first.
  2. Add the `<dependency>` (without version) to the consuming module.

---

## Anti-patterns to refuse

When suggesting changes, refuse the following with a brief explanation:

  - Adding `src/main/java` to the ROOT pom directory (it's an aggregator,
    not a code module).
  - Adding `<modules>` to a CHILD pom (modules don't nest).
  - Pinning a version in a CHILD pom for a dependency already managed at
    root.
  - Adding `rewrite.yml` or `MIGRATION_LOG.md` to a child module.
  - Running `mvn rewrite:run` from a child module directory (loses
    cross-module context — run from root).
  - Hand-editing version numbers in child poms instead of using
    `mvn versions:set -DprocessAllModules`.
  - Duplicating `<plugin>` declarations in child poms when
    `<pluginManagement>` already covers them at root.

---

## Quick check: am I in the root or a module?

```bash
# At root:
ls pom.xml validation/pom.xml common/pom.xml         # all exist
grep -c '<modules>' pom.xml                           # > 0

# In a module:
ls pom.xml ../pom.xml                                 # both exist
grep -c '<parent>' pom.xml                            # > 0
grep -c '<modules>' pom.xml                           # 0
```

When the agent receives a request, infer location from the file paths
in context. If unclear, ask the user before suggesting pom.xml edits —
the rules differ depending on which pom is being changed.
