#!/usr/bin/env bash
#
# install-migration-toolkit.sh
#
# Drops the Phase 1 modernization toolkit into a repo. Detects whether
# the current directory is the parent BOM, common library, or an app
# repo, and installs the appropriate rule files plus OpenRewrite recipe.
#
# USAGE:
#   1. Download all RULE-*.md files, rewrite.yml, rewrite-plugin-snippet.xml,
#      MIGRATION_LOG.md, and struts-to-spring.prompt into a single directory
#      (e.g. ~/migration-toolkit/).
#   2. Run this script from the ROOT of the repo you want to migrate:
#        cd /path/to/acme-parent-bom    # or acme-common, or acme-app-orders
#        TOOLKIT_DIR=~/migration-toolkit ./install-migration-toolkit.sh
#   3. The script detects the repo type from pom.xml and installs the right
#      files. It will not overwrite existing files unless --force is passed.
#
# FLAGS:
#   --force        Overwrite existing files in .continue/ and at repo root.
#   --type=TYPE    Skip auto-detection. TYPE is bom | common | app.
#   --dry-run      Show what would be installed, don't actually copy.
#
# REQUIRES:
#   bash 4+, standard Unix tools (cp, mkdir, grep, sed). No external deps.

set -euo pipefail

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------

TOOLKIT_DIR="${TOOLKIT_DIR:-$HOME/migration-toolkit}"
FORCE=false
DRY_RUN=false
REPO_TYPE=""

# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

log()  { printf '\033[1;34m[INFO]\033[0m  %s\n' "$*"; }
warn() { printf '\033[1;33m[WARN]\033[0m  %s\n' "$*" >&2; }
err()  { printf '\033[1;31m[ERROR]\033[0m %s\n' "$*" >&2; exit 1; }
ok()   { printf '\033[1;32m[OK]\033[0m    %s\n' "$*"; }

usage() {
    sed -n '3,25p' "$0" | sed 's/^# \?//'
    exit "${1:-0}"
}

# ----------------------------------------------------------------------------
# Argument parsing
# ----------------------------------------------------------------------------

for arg in "$@"; do
    case "$arg" in
        --force)                     FORCE=true ;;
        --dry-run)                   DRY_RUN=true ;;
        --type=bom)                  REPO_TYPE="bom" ;;
        --type=common)               REPO_TYPE="common" ;;
        --type=common-multimodule)   REPO_TYPE="common-multimodule" ;;
        --type=app)                  REPO_TYPE="app" ;;
        --type=app-multimodule)      REPO_TYPE="app-multimodule" ;;
        --type=*)                    err "Unknown --type. Use bom | common | common-multimodule | app | app-multimodule." ;;
        -h|--help)                   usage 0 ;;
        *)                           err "Unknown argument: $arg. Run with --help." ;;
    esac
done

# ----------------------------------------------------------------------------
# Pre-flight checks
# ----------------------------------------------------------------------------

[[ -f pom.xml ]] || err "No pom.xml in $(pwd). Run this script from a repo root."

[[ -d "$TOOLKIT_DIR" ]] || err "TOOLKIT_DIR not found: $TOOLKIT_DIR
Set TOOLKIT_DIR to the directory containing the downloaded files:
  TOOLKIT_DIR=/path/to/files ./install-migration-toolkit.sh"

# ----------------------------------------------------------------------------
# Repo type detection
# ----------------------------------------------------------------------------

detect_repo_type() {
    # BOM repo: <packaging>pom</packaging>, no <modules>, no src/main/java.
    # A pure dependency-management artifact.
    local has_pom_packaging=false
    local has_modules=false
    local has_java_src=false

    grep -q '<packaging>pom</packaging>' pom.xml && has_pom_packaging=true
    grep -q '<modules>' pom.xml && has_modules=true
    [[ -d src/main/java ]] && has_java_src=true

    if [[ "$has_pom_packaging" == true ]] && [[ "$has_modules" == false ]] && [[ "$has_java_src" == false ]]; then
        echo "bom"
        return
    fi

    # Multi-module common library: <packaging>pom</packaging> WITH <modules>,
    # AND artifactId looks like a common/shared library aggregator.
    local artifact_id
    artifact_id=$(grep -m1 '<artifactId>' pom.xml | sed 's/.*<artifactId>\(.*\)<\/artifactId>.*/\1/' || true)

    if [[ "$has_pom_packaging" == true ]] && [[ "$has_modules" == true ]]; then
        if [[ "$artifact_id" =~ -common ]] || [[ "$artifact_id" =~ ^common- ]] || [[ "$artifact_id" == "acme-common" ]]; then
            echo "common-multimodule"
            return
        fi
        # A multi-module aggregator that's not a common library — likely a
        # multi-module app. Fall through to app handling.
        echo "app-multimodule"
        return
    fi

    # Single-module common library
    if [[ "$artifact_id" =~ -common ]] || [[ "$artifact_id" =~ ^common- ]] || [[ "$artifact_id" == "acme-common" ]]; then
        echo "common"
        return
    fi

    # Default: single-module app repo
    echo "app"
}

if [[ -z "$REPO_TYPE" ]]; then
    REPO_TYPE=$(detect_repo_type)
    log "Auto-detected repo type: $REPO_TYPE"
    log "If wrong, re-run with --type=bom | --type=common | --type=app"
else
    log "Using user-specified repo type: $REPO_TYPE"
fi

# ----------------------------------------------------------------------------
# File mapping per repo type
# ----------------------------------------------------------------------------

# Each entry: "SOURCE_FILE_IN_TOOLKIT|TARGET_PATH_IN_REPO"
declare -a FILES_TO_INSTALL

case "$REPO_TYPE" in
    bom)
        FILES_TO_INSTALL=(
            "RULE-bom-repo-parent-bom-pom-rules.md|.continue/rules/parent-bom-pom-rules.md"
        )
        ;;
    common)
        FILES_TO_INSTALL=(
            "RULE-common-library-00-phase1-modernization.md|.continue/rules/00-phase1-modernization.md"
            "RULE-common-library-10-library-conventions.md|.continue/rules/10-library-conventions.md"
            "rewrite.yml|rewrite.yml"
            "MIGRATION_LOG.md|MIGRATION_LOG.md"
            "struts-to-spring.prompt|.continue/prompts/modernize.prompt"
        )
        ;;
    common-multimodule)
        # Multi-module common library: rules apply across the whole repo,
        # an extra rule explains the aggregator-root distinction.
        FILES_TO_INSTALL=(
            "RULE-common-library-00-phase1-modernization.md|.continue/rules/00-phase1-modernization.md"
            "RULE-common-library-10-library-conventions.md|.continue/rules/10-library-conventions.md"
            "RULE-multimodule-aggregator-root.md|.continue/rules/05-multimodule-aggregator-root.md"
            "rewrite.yml|rewrite.yml"
            "MIGRATION_LOG.md|MIGRATION_LOG.md"
            "struts-to-spring.prompt|.continue/prompts/modernize.prompt"
        )
        ;;
    app)
        FILES_TO_INSTALL=(
            "RULE-app-repo-00-phase1-modernization.md|.continue/rules/00-phase1-modernization.md"
            "RULE-app-repo-10-test-conventions.md|.continue/rules/10-test-conventions.md"
            "rewrite.yml|rewrite.yml"
            "MIGRATION_LOG.md|MIGRATION_LOG.md"
            "struts-to-spring.prompt|.continue/prompts/modernize.prompt"
        )
        ;;
    app-multimodule)
        FILES_TO_INSTALL=(
            "RULE-app-repo-00-phase1-modernization.md|.continue/rules/00-phase1-modernization.md"
            "RULE-app-repo-10-test-conventions.md|.continue/rules/10-test-conventions.md"
            "RULE-multimodule-aggregator-root.md|.continue/rules/05-multimodule-aggregator-root.md"
            "rewrite.yml|rewrite.yml"
            "MIGRATION_LOG.md|MIGRATION_LOG.md"
            "struts-to-spring.prompt|.continue/prompts/modernize.prompt"
        )
        ;;
    *)
        err "Unknown repo type: $REPO_TYPE"
        ;;
esac

# ----------------------------------------------------------------------------
# Verify all source files exist in toolkit
# ----------------------------------------------------------------------------

log "Verifying toolkit contents in $TOOLKIT_DIR..."
missing=()
for entry in "${FILES_TO_INSTALL[@]}"; do
    src="${entry%%|*}"
    if [[ ! -f "$TOOLKIT_DIR/$src" ]]; then
        missing+=("$src")
    fi
done

if [[ ${#missing[@]} -gt 0 ]]; then
    err "Missing files in $TOOLKIT_DIR:
$(printf '  - %s\n' "${missing[@]}")

Download the missing files into $TOOLKIT_DIR before running this script."
fi
ok "Toolkit complete: $(echo "${FILES_TO_INSTALL[@]}" | wc -w) files found"

# ----------------------------------------------------------------------------
# Install
# ----------------------------------------------------------------------------

log "Installing files for repo type: $REPO_TYPE"

installed_count=0
skipped_count=0
overwrote_count=0

for entry in "${FILES_TO_INSTALL[@]}"; do
    src="${entry%%|*}"
    dst="${entry##*|}"

    if [[ -f "$dst" ]] && [[ "$FORCE" != true ]]; then
        warn "SKIP: $dst already exists (use --force to overwrite)"
        ((skipped_count++)) || true
        continue
    fi

    if [[ "$DRY_RUN" == true ]]; then
        log "DRY-RUN: would copy $TOOLKIT_DIR/$src -> $dst"
        continue
    fi

    mkdir -p "$(dirname "$dst")"

    if [[ -f "$dst" ]]; then
        cp "$TOOLKIT_DIR/$src" "$dst"
        ok "OVERWROTE: $dst"
        ((overwrote_count++)) || true
    else
        cp "$TOOLKIT_DIR/$src" "$dst"
        ok "INSTALLED: $dst"
        ((installed_count++)) || true
    fi
done

# ----------------------------------------------------------------------------
# Post-install: pom.xml plugin block
# ----------------------------------------------------------------------------

if [[ "$REPO_TYPE" != "bom" ]]; then
    if grep -q "rewrite-maven-plugin" pom.xml 2>/dev/null; then
        log "pom.xml already contains rewrite-maven-plugin — no change needed"
    else
        warn ""
        warn "MANUAL STEP REQUIRED:"
        warn "  Add the OpenRewrite plugin block from:"
        warn "    $TOOLKIT_DIR/rewrite-plugin-snippet.xml"
        if [[ "$REPO_TYPE" == "common-multimodule" ]] || [[ "$REPO_TYPE" == "app-multimodule" ]]; then
            warn "  into the ROOT pom.xml under <build><pluginManagement><plugins>"
            warn "  (NOT in the child module poms — the recipe runs from root)."
            warn ""
            warn "  Then activate the recipe at root with:"
            warn "    <build><plugins><plugin>"
            warn "      <groupId>org.openrewrite.maven</groupId>"
            warn "      <artifactId>rewrite-maven-plugin</artifactId>"
            warn "    </plugin></plugins></build>"
            warn ""
            warn "  The <activeRecipes> config in the snippet ensures the same"
            warn "  recipe runs across every module from a single mvn invocation."
        else
            warn "  into your pom.xml under <build><plugins>."
        fi
        warn ""
        warn "  This script does NOT auto-edit pom.xml because XML edits are"
        warn "  high-risk for malformed output. Paste it manually and verify"
        warn "  with: mvn validate"
        warn ""
    fi
fi

# ----------------------------------------------------------------------------
# Post-install: gitignore reminders
# ----------------------------------------------------------------------------

if [[ -f .gitignore ]]; then
    if ! grep -qE '^target/' .gitignore; then
        warn ".gitignore does not exclude target/ — add it before committing"
    fi
fi

# ----------------------------------------------------------------------------
# Summary
# ----------------------------------------------------------------------------

echo
ok "============================================================"
ok "Installation complete for $REPO_TYPE repo"
ok "  Installed: $installed_count file(s)"
ok "  Overwrote: $overwrote_count file(s)"
ok "  Skipped:   $skipped_count file(s)"
ok "============================================================"

if [[ "$DRY_RUN" == true ]]; then
    log ""
    log "This was a dry run. No files were modified."
    log "Re-run without --dry-run to actually install."
    exit 0
fi

# ----------------------------------------------------------------------------
# Next steps
# ----------------------------------------------------------------------------

cat <<EOF

Next steps:

  1. Review installed files:
       git status
       git diff

  2. (App / common library only) Paste the OpenRewrite plugin block from
     $TOOLKIT_DIR/rewrite-plugin-snippet.xml
     into your pom.xml under <build><plugins>, then:
       mvn validate

  3. Edit MIGRATION_LOG.md — set repo name, baseline tag, and branch
     name at the top.

  4. Bump the parent BOM reference in pom.xml to:
       2.0.0-MIGRATION-SNAPSHOT
     (For app repos only: also bump acme-common to 2.0.0-MIGRATION-SNAPSHOT)

  5. Commit the scaffolding:
       git checkout -b migration-java21
       git add -A
       git commit -m "chore(migration): scaffold modernization toolkit"
       git push -u origin migration-java21

  6. Follow PHASE1_RUNBOOK.md from "Day 1" onwards.

EOF
