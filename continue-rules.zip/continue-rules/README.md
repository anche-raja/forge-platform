# Continue.dev Rules + Session Continuity Bundle

Drop-in rules and templates for using Continue.dev efficiently within a 200k-token budget,
with a session-handoff pattern that survives context-window resets.

## What's in here

```
continue-rules/
├── global-rules/                     → installs to ~/.continue/rules/
│   ├── 00-session-continuity.md      Always-on. Defines the HANDOFF pattern.
│   ├── 01-communication.md           Always-on. Concise, diff-style output.
│   ├── 02-java-standards.md          Scoped to **/*.java
│   ├── 03-python-standards.md        Scoped to **/*.py
│   ├── 04-aws.md                     Scoped to IaC files (CDK / Terraform / SAM)
│   ├── 05-sql.md                     Scoped to **/*.sql and migration paths
│   └── 06-security.md                Always-on. Flags injection / secret / crypto issues.
└── workspace-templates/              → copy into <each-project>/.continue/memory/
    ├── HANDOFF.md                    Session handoff note (overwrite each checkpoint)
    └── DECISIONS.md                  Append-only ADR-lite log
```

## Install

### 1. Global rules (apply to every project)

**macOS / Linux:**
```bash
mkdir -p ~/.continue/rules
cp global-rules/*.md ~/.continue/rules/
```

**Windows (PowerShell):**
```powershell
New-Item -ItemType Directory -Force -Path "$HOME\.continue\rules"
Copy-Item global-rules\*.md "$HOME\.continue\rules\"
```

Restart VSCode / IntelliJ. Rules are picked up automatically. Verify by opening the
Continue panel → click the rules icon — you should see all 7 listed.

### 2. Workspace memory (per project)

Inside each project repo:
```bash
mkdir -p .continue/memory
cp /path/to/workspace-templates/*.md .continue/memory/
```

Add to your project's `.gitignore` if you don't want the handoff/decisions tracked
(personal notes), OR commit them if your team shares context (recommended for DECISIONS.md).

```gitignore
# personal session notes
.continue/memory/HANDOFF.md
# but keep team decisions log
!.continue/memory/DECISIONS.md
```

## Daily workflow

1. **Start of session:** open Continue chat. The `00-session-continuity` rule will make
   the agent read `HANDOFF.md` automatically and confirm what state it recovered.
2. **Mid-session:** work normally. When you make a non-obvious architectural choice,
   say *"log decision: <one line>"* — the agent appends to `DECISIONS.md`.
3. **Before stopping (or when context approaches ~70%):** type **`checkpoint`**. The
   agent writes/overwrites `HANDOFF.md` with goal, state, decisions, next steps, gotchas.
4. **Next session:** open chat → it reads the handoff → you're back in flow in <2k tokens
   instead of 50k of re-explanation.

## Tuning the rules

- **Adjust globs** in `02`–`05` to match your repo layout (e.g., `src/main/java/**/*.java`).
- **Add stack-specific rules** by copying the pattern: filename `NN-topic.md`, frontmatter
  with `name:` and either `alwaysApply: true` or `globs: [...]`, then markdown body.
- **Workspace overrides:** if a project needs different rules, drop `.md` files into
  `<project>/.continue/rules/` — they override global rules of the same name.

## Token-budget tips (with 200k cap)

- Set autocomplete to a separate cheap/local model (Ollama Codestral or Claude Haiku) —
  don't burn chat budget on tab-completions.
- Use `@file`, `@code`, `@folder`, `@docs` references instead of pasting code.
- Add a `.continueignore` at repo root to exclude `node_modules`, `target/`, `build/`,
  generated files, large fixtures.
- Index docs sites (AWS, Postgres, Spring) once via `@docs` — embeddings are free,
  re-use across all sessions.
- Prefer **Edit mode** (`Cmd/Ctrl+I`) for small inline changes; reserve **Agent mode**
  for genuine multi-file or tool-using tasks (it eats tokens fast).

## Reference

- Continue rules docs: https://docs.continue.dev/customize/deep-dives/rules
- Continue config reference: https://docs.continue.dev/reference
- Awesome rules collection: https://github.com/continuedev/awesome-rules
