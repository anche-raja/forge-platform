---
name: AWS Patterns
globs: ["**/cdk/**", "**/terraform/**", "**/serverless.yml", "**/template.yaml", "**/template.yml", "**/*.tf"]
---

# AWS Patterns

## Infrastructure
- IaC only — never suggest console clicks except for one-time bootstrap (root account, initial OIDC).
- Prefer CDK (TypeScript or Python) or Terraform. No CloudFormation YAML by hand for new stacks.
- Tag every resource: `Project`, `Environment`, `Owner`, `CostCenter`.

## IAM
- Least-privilege always. No wildcard `Action: "*"` or `Resource: "*"` except for explicitly logged exceptions.
- Prefer IAM roles over IAM users; OIDC federation for CI/CD.
- Inline policies for one-off; managed policies when reused.

## Secrets
- SSM Parameter Store (SecureString) or Secrets Manager. Never env vars for secrets in code.
- Never commit `.env`, `.pem`, AWS keys. Flag if seen in a diff.

## Lambda
- Cold-start awareness: keep handler imports light; lazy-import heavy deps inside the handler.
- Memory ≥ 512 MB unless profiled lower; CPU scales with memory.
- Timeouts: set explicitly per function, don't default to 3s.
- Use Powertools (Python/Java/Node) for logging, tracing, metrics.

## DynamoDB
- Design access patterns first, then keys. Ask me for query patterns before suggesting a schema.
- Single-table design unless there's a clear reason against.
- GSIs cost money — justify each one.
- Use `ConditionExpression` for optimistic locking; never read-then-write without it.

## S3
- Block public access at account and bucket level by default.
- Versioning + lifecycle rules on anything that matters.
- SSE-S3 minimum; SSE-KMS for sensitive data.
