---
name: Security Defaults
alwaysApply: true
---

# Security Defaults

## Secrets & credentials
- Never suggest committing secrets, keys, tokens, or `.env` contents.
- If a secret appears in a paste or diff, flag it immediately and recommend rotation.
- No hardcoded credentials in tests, fixtures, or examples — use placeholders like `<API_KEY>`.

## Input handling
- Treat all external input as hostile: HTTP params, headers, message payloads, file uploads, env vars at runtime.
- Validate at the edge; don't propagate untrusted data into queries, shells, or templates.

## Injection vectors — flag any of these in suggested code
- String concatenation building SQL, shell commands, HTML, LDAP queries, or XPath.
- `eval`, `exec`, `Runtime.exec`, `os.system`, `subprocess.run(shell=True)`, `child_process.exec` with user input.
- Templates rendered without auto-escaping.
- Deserialization of untrusted data (Java `ObjectInputStream`, Python `pickle`, `yaml.load` without `SafeLoader`).

## Auth & sessions
- Hash passwords with argon2id or bcrypt; never MD5/SHA1.
- JWTs: verify signature, check `exp`, validate `iss`/`aud`. Never trust the `alg` header value alone — pin it.
- Session cookies: `HttpOnly`, `Secure`, `SameSite=Lax` minimum.

## Dependencies
- Don't suggest packages from memory if uncertain — they may not exist (or worse, be typosquats).
- Flag obviously abandoned/unmaintained libs.
