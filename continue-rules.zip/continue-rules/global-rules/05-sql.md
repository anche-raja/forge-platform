---
name: SQL Standards
globs: ["**/*.sql", "**/migrations/**", "**/migration/**", "**/db/**"]
---

# SQL Standards

## Universal
- Parameterized queries always; never string concatenation.
- Explicit column lists in `INSERT` and `SELECT` for production code. No `SELECT *`.
- Index every FK and every column used in `WHERE`/`JOIN`/`ORDER BY` on hot paths.
- Migrations are forward-only; write a rollback note in the file header, not a separate down-migration script.

## Postgres
- Prefer `jsonb` over `json`.
- Use `text` over `varchar(n)` unless there's a real constraint.
- `timestamptz` always; never naive `timestamp`.
- Use `CTE` for readability when the planner doesn't penalize it (Postgres 12+).
- `ON CONFLICT` for upserts.
- Partial indexes for sparse predicates.

## Oracle
- Bind variables, not literals — kills cursor cache otherwise.
- Hints only when justified with an `EXPLAIN PLAN` showing the optimizer's bad choice.
- `MERGE` for upserts.
- Sequences + identity columns for surrogate keys, not application-generated IDs.

## Schema review
- New tables need: PK, `created_at`, `updated_at`, audit columns if user-facing.
- No nullable booleans without a documented reason (3-state surprise).
- Foreign keys with explicit `ON DELETE` behavior — don't default.
