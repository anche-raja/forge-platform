---
name: Session Continuity
alwaysApply: true
---

# Session Continuity Protocol

Conversation context is finite (~200k tokens) and is lost between sessions.
Persist state to disk so work survives session boundaries.

## At session start
1. Check for `./.continue/memory/HANDOFF.md` in the workspace. If present, read it before answering.
2. Check for `./.continue/memory/DECISIONS.md` (architectural decisions log) and read if present.
3. Briefly confirm to me what state you've recovered, then await direction.

## During a session
- When I say "checkpoint" or "handoff", write/overwrite `./.continue/memory/HANDOFF.md` with:
  - **Goal**: what we're working on
  - **State**: what's done, what's in-flight (with file paths + line refs)
  - **Decisions**: choices made and why (1 line each)
  - **Next steps**: ordered TODOs to resume on
  - **Gotchas**: traps, dead-ends already explored, env quirks
- Keep HANDOFF.md under 300 lines. Compress old content; don't accumulate.
- When making non-obvious architectural choices, append a one-line entry to `./.continue/memory/DECISIONS.md` with date.

## When context feels full
If you notice you're losing earlier instructions, proactively suggest "checkpoint and start fresh" rather than continuing degraded.

## Reference, don't dump
Prefer `@file` and `@code` references over pasting whole files into chat.
