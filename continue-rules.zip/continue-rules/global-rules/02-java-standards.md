---
name: Java Standards
globs: ["**/*.java"]
---

# Java Standards

## Language
- Java 21+ idioms: records, pattern matching, sealed types, text blocks where they fit.
- `var` for obvious local types; explicit types when it aids readability.
- Streams are fine for transforms; loops for side effects.

## Frameworks / DI
- Constructor injection only; no field injection (`@Autowired` on fields is banned).
- Prefer `@RequiredArgsConstructor` (Lombok) or explicit constructors.
- No `static` mutable state.

## Errors
- No checked exceptions in new APIs; wrap in unchecked at boundaries.
- Don't swallow exceptions. Log with context or rethrow.
- Custom exceptions extend a project base class, not `RuntimeException` directly.

## Logging
- SLF4J only; no `System.out` / `printStackTrace`.
- Parameterized logging: `log.info("user {} did {}", userId, action)` — never string concatenation.
- Levels: ERROR (action needed), WARN (recoverable), INFO (lifecycle), DEBUG (diagnostic).

## Tests
- JUnit 5 + AssertJ. No Hamcrest in new code.
- Method names: `methodName_condition_expectedResult`.
- One assertion-per-concept; multiple `assertThat` lines fine when testing one behavior.
- Use `@ParameterizedTest` instead of duplicating test bodies.
