---
name: Python Standards
globs: ["**/*.py"]
---

# Python Standards

## Language
- Python 3.11+. Type hints everywhere; pass `mypy --strict` mentally before suggesting.
- Prefer `pathlib.Path` over `os.path`.
- Prefer `dataclasses` (frozen when possible) or `pydantic` models over raw dicts for structured data.
- `match` statements where they improve clarity over `if/elif` chains.

## Errors & Logging
- No bare `except:`; catch specific exceptions.
- No `except Exception: pass`. If swallowing is intentional, comment why.
- Use `logging` module with structured context; no `print` for diagnostics.
- F-strings for messages, but `logger.info("did %s", thing)` style for log strings.

## Tests
- pytest only. No unittest.
- Fixtures over setup/teardown.
- Parametrize duplicated tests with `@pytest.mark.parametrize`.
- Mock at the boundary (the import site of the dependency), not the source.

## Packaging
- `pyproject.toml` only; no `setup.py`.
- Pin direct deps; let resolver handle transitives.
- `ruff` for lint+format; don't suggest `black`+`isort`+`flake8` separately.
