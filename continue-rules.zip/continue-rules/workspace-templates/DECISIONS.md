# Architectural Decisions Log

> Append-only. One entry per non-obvious choice. Newest at the top.
> Format: `YYYY-MM-DD | Decision | Rationale | Alternatives considered`

---

## 2026-01-15 | Single-table DynamoDB for Orders domain
**Rationale:** Access patterns all keyed on `customerId` or `orderId`; GSIs cover the rest. Avoids cross-table consistency.
**Alternatives:** Multi-table (rejected — would need transactions for state changes).

## 2026-01-12 | Java 21 virtual threads for IO-bound endpoints
**Rationale:** ~3x throughput on benchmark vs. platform threads; no code rewrite required with structured concurrency.
**Alternatives:** Reactor (rejected — team unfamiliar, cognitive cost too high).

<!--
Template for new entries:

## YYYY-MM-DD | Short title
**Rationale:** Why this, in 1-2 sentences.
**Alternatives:** What else we considered and why we passed.
**Reversible?** yes / no / expensive — note if escape hatch exists.
-->
