# Session Handoff

> Overwritten on each "checkpoint" command. Read this first when starting a new session.

**Last updated:** YYYY-MM-DD HH:MM
**Branch / commit:** `feature/xyz @ <sha>`

---

## Goal
<!-- One sentence: what are we trying to accomplish in this work stream? -->

## Current state

### Done
- [ ] Item with file path: `src/path/file.java:42`
- [ ] Item with file path: `src/path/file.java:88`

### In flight
- [ ] What's half-done, where, and what's the blocker?

### Not started
- [ ] Ordered next steps to resume on.

---

## Decisions (recent)
<!-- 1 line each. Move older items to DECISIONS.md when this gets long. -->
- Chose X over Y because Z.
- Rejected approach A — incompatible with constraint B.

---

## Gotchas
<!-- Things that wasted time. Future-you will thank present-you. -->
- Local DB needs `ENABLE_FOO=true` env var or migrations fail silently.
- The `legacy/` module uses Java 8 — don't suggest Java 21 idioms there.
- Test suite flakes on `OrderServiceIT` when run in parallel; use `-p 1`.

---

## Open questions
<!-- Things to ask the human or research next session. -->
- [ ] Should we keep the in-memory cache or move to Redis?

---

## Reference files
<!-- Files the next session should re-read to get oriented quickly. -->
- `src/main/java/.../OrderService.java`
- `infra/cdk/lib/order-stack.ts`
- `docs/architecture/orders.md`
